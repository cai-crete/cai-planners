/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import Canvas from './components/Canvas';
import { useStore } from './store/useStore';
import { Sun, Moon } from 'lucide-react';

export default function App() {
  const { loadProjectsList, projects, createNewProject, toggleRightPanel } = useStore();
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const init = async () => {
      await loadProjectsList();
      if (useStore.getState().projects.length === 0) {
        createNewProject();
      }
    };
    init();
  }, [loadProjectsList, createNewProject]);

  const handleToggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    if (!isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-neutral-50 text-neutral-900 transition-colors dark:bg-neutral-950 dark:text-neutral-50">
      <div className="absolute top-4 right-20 z-[60] flex items-center gap-4 bg-white/50 dark:bg-neutral-900/50 backdrop-blur-md px-4 py-2 rounded-full shadow-sm border border-neutral-200 dark:border-neutral-800">
        <button 
          onClick={toggleRightPanel}
          className="text-sm font-bold tracking-widest uppercase text-neutral-900 hover:text-blue-600 transition-colors dark:text-white dark:hover:text-blue-400"
        >
          LIBRARY
        </button>
        <button 
          onClick={handleToggleDarkMode}
          className="p-1.5 rounded-full hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors"
        >
          {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>
      </div>
      <Canvas />
    </div>
  );
}
