import { memo, useEffect, useState } from 'react';
import { useStore } from '../store/useStore';
import { useReactFlow } from '@xyflow/react';
import { Sparkles } from 'lucide-react';
import { generateDiscussion } from '../lib/gemini';

export const FloatingToolbar = memo(() => {
  const { nodes, isGenerating, setIsGenerating, addNode, onConnect, currentMode, selectedExpertIds, generationTurn, setGenerationTurn } = useStore();
  const { getNodes } = useReactFlow();
  const [selectedNodes, setSelectedNodes] = useState<any[]>([]);

  useEffect(() => {
    const selected = nodes.filter((n) => n.selected);
    setSelectedNodes(selected);
  }, [nodes]);

  if (selectedNodes.length === 0 || isGenerating) {
    return null;
  }

  const handleGenerate = async () => {
    if (generationTurn >= 3) {
      alert('최대 턴(3턴)에 도달했습니다. 새로운 캔버스에서 시작하거나 다른 노드를 선택하세요.');
      return;
    }

    setIsGenerating(true);
    try {
      // 1. 컨텍스트 수집 (선택된 노드들의 텍스트)
      const context = selectedNodes.map(n => n.data.text || n.data.content).join('\\n\\n');
      
      // 2. Gemini API 호출
      const result = await generateDiscussion(context, currentMode, selectedExpertIds);
      
      const lastSelectedNode = selectedNodes[selectedNodes.length - 1];
      const startX = lastSelectedNode.position.x + 350;
      const startY = lastSelectedNode.position.y;
      const currentTurn = generationTurn + 1;

      // 3. 순차적 노드 생성 (애니메이션 효과)
      const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

      // Thesis Node
      const thesisId = `node-thesis-${Date.now()}`;
      addNode({
        id: thesisId,
        type: 'discussion',
        position: { x: startX, y: startY - 150 },
        data: { type: 'thesis', expertId: result.thesis.expertId, content: result.thesis.content, turn: currentTurn }
      });
      selectedNodes.forEach(node => {
        onConnect({ source: node.id, target: thesisId, sourceHandle: null, targetHandle: null });
      });

      await delay(1500);

      // Antithesis Node
      const antithesisId = `node-anti-${Date.now()}`;
      addNode({
        id: antithesisId,
        type: 'discussion',
        position: { x: startX + 400, y: startY - 150 },
        data: { type: 'antithesis', expertId: result.antithesis.expertId, content: result.antithesis.content, turn: currentTurn }
      });
      onConnect({ source: thesisId, target: antithesisId, sourceHandle: null, targetHandle: null });

      await delay(1500);

      // Synthesis Node
      const synthesisId = `node-syn-${Date.now()}`;
      addNode({
        id: synthesisId,
        type: 'discussion',
        position: { x: startX + 200, y: startY + 150 },
        data: { type: 'synthesis', expertId: result.synthesis.expertId, content: result.synthesis.content, turn: currentTurn }
      });
      onConnect({ source: thesisId, target: synthesisId, sourceHandle: null, targetHandle: null });
      onConnect({ source: antithesisId, target: synthesisId, sourceHandle: null, targetHandle: null });

      setGenerationTurn(currentTurn);
      setIsGenerating(false);

    } catch (error) {
      console.error('Generation failed:', error);
      alert('토론 생성에 실패했습니다. 다시 시도해주세요.');
      setIsGenerating(false);
    }
  };

  return (
    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 rounded-full bg-white px-6 py-3 shadow-2xl border border-neutral-200 animate-in slide-in-from-bottom-4">
      <span className="text-sm font-medium text-neutral-600">
        {selectedNodes.length} nodes selected
      </span>
      <div className="h-4 w-px bg-neutral-200" />
      <button
        onClick={handleGenerate}
        className="flex items-center gap-2 rounded-full bg-black px-4 py-2 text-sm font-bold text-white hover:bg-neutral-800 transition-colors"
      >
        <Sparkles className="h-4 w-4" /> GENERATE
      </button>
    </div>
  );
});
