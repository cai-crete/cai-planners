import { memo, useMemo, useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { EXPERTS } from '../lib/experts';
import { cn } from '../lib/utils';
import { 
  X, Copy, Download, ChevronRight, Settings, 
  Folder, Plus, Trash2, Bot, Layers, Check, Loader2, ChevronDown
} from 'lucide-react';
import Markdown from 'react-markdown';
import { summarizeNote } from '../lib/enhanceNote';

export const RightPanel = memo(() => {
  const {
    isRightPanelOpen,
    toggleRightPanel,
    selectedNodeId,
    setSelectedNodeId,
    nodes,
    projects,
    currentProjectId,
    createNewProject,
    loadProjectData,
    deleteProjectData,
    autoExpertMode,
    setAutoExpertMode,
    selectedExpertIds,
    toggleExpertSelection,
  } = useStore();

  const selectedNode = useMemo(() => nodes.find(n => n.id === selectedNodeId), [nodes, selectedNodeId]);
  const expert = useMemo(() => {
    if (selectedNode?.type === 'discussion') {
      return EXPERTS.find(e => e.id === (selectedNode.data as any).expertId);
    }
    return null;
  }, [selectedNode]);

  const stickyFullText = selectedNode?.type === 'sticky' ? ((selectedNode.data as any).fullText || (selectedNode.data as any).text) : undefined;
  
  const [editedText, setEditedText] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isExpertsOpen, setIsExpertsOpen] = useState(false);

  useEffect(() => {
    if (stickyFullText !== undefined) {
      setEditedText(stickyFullText);
    }
  }, [selectedNodeId, stickyFullText]);

  const handleSave = async () => {
    if (!selectedNode || !editedText.trim() || isSaving) return;
    setIsSaving(true);
    try {
      const summary = await summarizeNote(editedText);
      useStore.getState().updateNodeData(selectedNode.id, { text: summary, fullText: editedText });
    } catch (e) {
      alert("요약 생성에 실패했습니다.");
    } finally {
      setIsSaving(false);
    }
  };

  const isModified = stickyFullText !== undefined && editedText !== stickyFullText;

  // Copy handles discussion nodes
  const handleCopy = () => {
    if (!selectedNode) return;
    const text = (selectedNode.data as any).content || (selectedNode.data as any).text;
    if (text) {
      navigator.clipboard.writeText(text);
    }
  };

  return (
    <div 
      className={cn(
        "absolute top-4 bottom-4 z-40 transition-all duration-300 ease-in-out flex items-start",
        isRightPanelOpen ? "right-4" : "-right-80"
      )}
    >
      {/* Toggle Button */}
      <button 
        onClick={toggleRightPanel}
        className="mr-4 mt-2 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white shadow-md border border-neutral-200 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50 transition-colors"
        title={isRightPanelOpen ? "Close Panel" : "Open Settings & Library"}
      >
        {isRightPanelOpen ? <ChevronRight className="h-5 w-5" /> : <Settings className="h-5 w-5" />}
      </button>

      {/* Panel Container */}
      <div className="w-80 h-full bg-white/90 backdrop-blur-xl shadow-2xl border border-neutral-200 rounded-2xl flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-100 p-4 bg-white/50">
          <h2 className="text-sm font-bold tracking-tight text-neutral-900 flex items-center gap-2">
            <Layers className="h-4 w-4 text-neutral-500" />
            Workspace
          </h2>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          
          {/* Node Details Section */}
          {selectedNode && (
            <div className="border-b border-neutral-100 bg-blue-50/30">
              <div className="flex items-center justify-between p-4 pb-2">
                <h3 className="text-xs font-bold uppercase tracking-widest text-blue-600">CODE</h3>
                <button onClick={() => setSelectedNodeId(null)} className="rounded-md p-1 hover:bg-blue-100 text-neutral-400 hover:text-neutral-600 transition-colors">
                  <X className="h-4 w-4" />
                </button>
              </div>
              
              <div className="px-4 pb-4">
                {selectedNode.type === 'discussion' ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      {expert?.avatarUrl ? (
                        <img src={expert.avatarUrl} alt={expert.name} className="h-8 w-8 rounded-full bg-neutral-200 object-cover" />
                      ) : (
                        <div className="h-8 w-8 rounded-full bg-neutral-200" />
                      )}
                      <div>
                        <div className="text-sm font-bold text-neutral-900">{expert?.name || 'Unknown Expert'}</div>
                        <div className="text-xs text-neutral-500">{expert?.role || 'Expert'}</div>
                      </div>
                    </div>
                    
                    <div className="prose prose-sm prose-neutral max-w-none text-xs max-h-40 overflow-y-auto custom-scrollbar">
                      <Markdown>{(selectedNode.data as any).content || ''}</Markdown>
                    </div>

                    <div className="mt-4 flex gap-2">
                      <button
                        onClick={handleCopy}
                        className="flex-1 flex items-center justify-center gap-1.5 rounded-md border border-neutral-200 bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 hover:bg-neutral-50 transition-colors"
                      >
                        <Copy className="h-3.5 w-3.5" /> Copy
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 flex flex-col">
                    {(selectedNode.data as any).imageUrl && (
                      <img src={(selectedNode.data as any).imageUrl} alt="Sticky Note" className="w-full rounded-md border border-neutral-200 object-cover max-h-32" />
                    )}
                    <textarea
                      value={editedText}
                      onChange={(e) => setEditedText(e.target.value)}
                      className="w-full min-h-[160px] resize-none rounded-md border border-neutral-200 bg-white p-2 text-xs text-neutral-800 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 custom-scrollbar"
                      placeholder="내용을 입력하세요..."
                    />
                    
                    <div className="mt-2 flex justify-end h-[32px]">
                      {isModified && (
                        <button
                          onClick={handleSave}
                          disabled={isSaving}
                          className="w-[calc(50%-0.25rem)] flex items-center justify-center gap-1.5 rounded-md bg-neutral-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-neutral-800 transition-colors disabled:bg-neutral-400"
                        >
                          {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                          {isSaving ? 'Saving...' : 'Save'}
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Library / Projects */}
          <div className="p-4 border-b border-neutral-100">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-500 flex items-center gap-2">
                <Folder className="h-3.5 w-3.5" /> Library
              </h3>
              <button 
                onClick={createNewProject} 
                className="rounded-md p-1 hover:bg-neutral-100 text-neutral-400 hover:text-neutral-900 transition-colors"
                title="New Project"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-1 max-h-48 overflow-y-auto custom-scrollbar pr-1">
              {projects.map(p => (
                <div 
                  key={p.id} 
                  className={cn(
                    "group flex items-center justify-between p-2 rounded-md text-sm cursor-pointer transition-colors", 
                    currentProjectId === p.id ? "bg-neutral-100 text-neutral-900 font-medium" : "hover:bg-neutral-50 text-neutral-600"
                  )}
                >
                  <span onClick={() => loadProjectData(p.id)} className="truncate flex-1">{p.name}</span>
                  {projects.length > 1 && (
                    <button 
                      onClick={(e) => { e.stopPropagation(); deleteProjectData(p.id); }} 
                      className="p-1 text-neutral-400 hover:text-red-500 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Delete Project"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Expert Settings */}
          <div className="p-4 border-t border-neutral-100">
            <div 
              className="flex items-center justify-between mb-2 cursor-pointer"
              onClick={() => setIsExpertsOpen(!isExpertsOpen)}
            >
              <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-500 flex items-center gap-2">
                <Bot className="h-3.5 w-3.5" /> Experts
              </h3>
              <div className="flex items-center gap-2">
                <button 
                  onClick={(e) => { e.stopPropagation(); setAutoExpertMode(!autoExpertMode); }} 
                  className={cn(
                    "text-[10px] px-2 py-1 rounded-full font-bold uppercase tracking-wider transition-colors border", 
                    autoExpertMode ? "bg-blue-50 text-blue-600 border-blue-200" : "bg-neutral-50 text-neutral-500 border-neutral-200"
                  )}
                >
                  Auto: {autoExpertMode ? 'ON' : 'OFF'}
                </button>
                <ChevronDown className={cn("h-4 w-4 text-neutral-400 transition-transform", isExpertsOpen ? "rotate-180" : "")} />
              </div>
            </div>
            
            {isExpertsOpen && (
              <div className={cn("mt-2 space-y-1 transition-opacity duration-200", autoExpertMode ? "opacity-50 pointer-events-none" : "opacity-100")}>
                {EXPERTS.map(expert => {
                  const isSelected = selectedExpertIds.includes(expert.id);
                  return (
                    <label 
                      key={expert.id} 
                      className={cn(
                        "flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer transition-colors border",
                        isSelected ? "bg-white border-neutral-200 shadow-sm" : "bg-transparent border-transparent hover:bg-neutral-50"
                      )}
                    >
                      <div className={cn(
                        "flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors",
                        isSelected ? "border-blue-600 bg-blue-600 text-white" : "border-neutral-300 bg-white"
                      )}>
                        {isSelected && <Check className="h-3 w-3" />}
                      </div>
                      <input 
                        type="checkbox" 
                        className="sr-only"
                        checked={isSelected}
                        onChange={() => toggleExpertSelection(expert.id)}
                      />
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <div className="h-5 w-5 rounded-full bg-neutral-200 overflow-hidden shrink-0">
                          {expert.avatarUrl && <img src={expert.avatarUrl} alt="" className="h-full w-full object-cover" />}
                        </div>
                        <span className="text-xs font-medium text-neutral-700 truncate">{expert.name}</span>
                      </div>
                    </label>
                  );
                })}
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
});
