import { GoogleGenAI, Type } from '@google/genai';
import { EXPERTS } from './experts';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface DiscussionResult {
  thesis: {
    expertId: string;
    content: string;
  };
  antithesis: {
    expertId: string;
    content: string;
  };
  synthesis: {
    expertId: string;
    content: string;
  };
}

export async function generateDiscussion(
  context: string,
  mode: string | null,
  selectedExpertIds: string[]
): Promise<DiscussionResult> {
  const availableExperts = EXPERTS.filter(e => selectedExpertIds.includes(e.id));
  
  // 간단한 스쿼드 구성 로직 (실제로는 모드에 따라 더 정교하게 구성)
  const squad = availableExperts.slice(0, 3);
  if (squad.length < 3) {
    throw new Error('최소 3명의 전문가가 필요합니다.');
  }

  const prompt = `
당신은 ES-MoE 기반 다중 전문가 토론 엔진입니다.
다음 컨텍스트를 바탕으로 3명의 전문가가 [제안 -> 반박 -> 통합]의 변증법적 토론을 진행하십시오.

컨텍스트:
${context}

참여 전문가:
1. 제안 (Thesis): ${squad[0].name} (${squad[0].role}) - ${squad[0].description}
2. 반박 (Antithesis): ${squad[1].name} (${squad[1].role}) - ${squad[1].description}
3. 통합 (Synthesis): ${squad[2].name} (${squad[2].role}) - ${squad[2].description}

각 전문가의 페르소나에 완벽히 빙의하여, 깊이 있고 논리적인 주장을 펼치십시오.
반박은 제안의 논리적 허점이나 현실적 제약을 날카롭게 지적해야 하며,
통합은 두 주장의 장점을 취해 실행 가능한 최적의 대안을 제시해야 합니다.
`;

  const config = {
    responseMimeType: 'application/json',
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        thesis: {
          type: Type.OBJECT,
          properties: {
            expertId: { type: Type.STRING, description: '제안을 담당한 전문가의 ID (예: T01)' },
            content: { type: Type.STRING, description: '제안 내용 (마크다운 포맷)' }
          },
          required: ['expertId', 'content']
        },
        antithesis: {
          type: Type.OBJECT,
          properties: {
            expertId: { type: Type.STRING, description: '반박을 담당한 전문가의 ID' },
            content: { type: Type.STRING, description: '반박 내용 (마크다운 포맷)' }
          },
          required: ['expertId', 'content']
        },
        synthesis: {
          type: Type.OBJECT,
          properties: {
            expertId: { type: Type.STRING, description: '통합을 담당한 전문가의 ID' },
            content: { type: Type.STRING, description: '통합 내용 (마크다운 포맷)' }
          },
          required: ['expertId', 'content']
        }
      },
      required: ['thesis', 'antithesis', 'synthesis']
    }
  } as any;

  try {
    let response;
    try {
      response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config
      });
    } catch (primaryError) {
      console.warn('Fallback to gemini-2.5-pro due to primary model failure:', primaryError);
      response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config
      });
    }

    const resultText = response.text;
    if (!resultText) throw new Error('No response from Gemini');
    
    const result = JSON.parse(resultText) as DiscussionResult;
    
    // 강제로 expertId 할당 (모델이 잘못된 ID를 반환할 경우 대비)
    result.thesis.expertId = squad[0].id;
    result.antithesis.expertId = squad[1].id;
    result.synthesis.expertId = squad[2].id;

    return result;
  } catch (error) {
    console.error('Gemini API Error:', error);
    throw error;
  }
}
